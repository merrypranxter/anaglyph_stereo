# anaglyph_stereo

A creative coding project exploring **stereoscopic illusions** — anaglyph encoding (red-cyan glasses), lenticular interlacing (angle-dependent view switching), and wiggle parallax (no-glasses 3D-GIF). A finisher that requires a depth map.

## What Is This?

A **finisher** that takes a source image + depth map and generates stereoscopic output. Three distinct modes: optimized Dubois matrix anaglyph (for glasses), lenticular strip interlacing (simulated angle tilt), and wiggle parallax (retro 3D-GIF oscillation).

**Adjacency note:** The `wiggle_parallax` mode overlaps with `parallax_depth_fields`. This repo owns **anaglyph + lenticular**; wiggle is a bonus mode. Pure parallax depth belongs to that repo.

## Project Structure

```
src/
  js/
    main.js           — WebGL setup, render loop, parameter UI
    source.js         — image + depth upload / webcam / upstream FBO
    dubois.js         — optimized Dubois matrix definitions
  shaders/
    depth/            — swappable depth sources
      sdf-scene.glsl  — SDF-based depth generation
      raymarch-depth.glsl — raymarched depth
      upload-depth.glsl — uploaded depth map passthrough
    views.frag        — generate L/R/N views via depth-shift
    anaglyph.frag     — channel-matrix composite (Dubois)
    lenticular.frag   — N-view strip interlace by angle
    post-process.frag — ghost-reduction blur, chromatic
```

## Running

Open `index.html` in any modern browser. WebGL2 required.

## Current Engines

- [ ] _anaglyph_dubois — optimized matrix anaglyph, least ghosting
- [ ] _anaglyph_color — naive red/cyan channel split
- [ ] _lenticular_flip — N-view strip interlace, angle-driven
- [ ] _wiggle_parallax — 2-view 6Hz oscillation, no glasses

## Aesthetic Regimes

- [ ] red_cyan_classic — Dubois anaglyph, for glasses, minimal ghosting
- [ ] lenticular_ripple — N=8 views, mouse-driven angle → holographic shimmer
- [ ] wiggle_gif — 2-view 6Hz wobble, no glasses, retro 3D-GIF
- [ ] depth_glitch — exaggerated separation → channel-tearing artifact aesthetic

## Parameters

- `separation` — eye distance in UV (0.0–0.2)
- `depth_scale` — parallax depth multiplier (0.0–2.0)
- `mode` — anaglyph_dubois | anaglyph_color | lenticular | wiggle
- `view_count` — 2–16 (for lenticular)
- `angle_drive` — mouse | time | gyro

## Ecosystem Hooks

Consumes depth from `sdf_fields`, `raymarching`, `parallax_depth_fields`. Pairs with `chromatic_aberration`, `op_art_style`.

---

*The left eye and the right eye disagree, and the brain invents depth.*
