// anaglyph_stereo — dubois.js
// Optimized Dubois anaglyph matrices.
