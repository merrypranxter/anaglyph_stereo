// anaglyph_stereo — color-maps.js
// 256px DataTexture ramps. Neon palettes sampled by scalar.

export const PALETTES = {
  acid: ['#0a001a','#8338ec','#ff006e','#ffbe0b','#fb5607'],
  void_bloom: ['#000000','#3a0ca3','#f72585','#4cc9f0','#ffffff'],
  plasma: ['#1a0000','#8b0000','#ff4500','#ffd700','#ffffff'],
  // add more
};

export function buildRamp(gl, hexArray) {
  // TODO: DataTexture from hex → RGBA
}
