// anaglyph_stereo — main.js
// Entry point. Sets up WebGL context, shader program, FBOs, and render loop.

const canvas = document.createElement('canvas');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
document.body.appendChild(canvas);
const gl = canvas.getContext('webgl2');

// TODO: compile shaders, init FBOs, start loop
